export const appTitle = "Student Showcase ";
export const appAuthor = "Josh Solomon";
export const endPointAllProfiles = "http://127.0.0.1:3003/api/profiles";
export const profilePicsBasePath = "http://127.0.0.1:3003/";
